"""Feedback motor for pinned finite-stroke belt surface; never references the cartons."""
from scripts.workcell_agent.choreonoid_tasks import EVENTS
import math
def initialize(io):
    global j,cmd,vel,settle,req,seen
    io.enable_input('Stroke');io.enable_output('Stroke','position')
    j=io.body.link('Stroke');cmd=float(j.q);vel=0.;settle=0.;req=-1;seen=-1
    return True
def control(io):
    global cmd,vel,settle,req,seen
    for e in EVENTS[-10:]:
        if e.get('event')=='index_request' and e['slot']>req:
            req=e['slot'];settle=0.
    goal=(.017+.052*req) if req>=0 else 0.
    delta=goal-cmd
    brake=math.sqrt(2*.20*abs(delta))
    vgoal=math.copysign(min(.055,brake,abs(delta)/io.dt),delta)
    vel+=max(-.20*io.dt,min(.20*io.dt,vgoal-vel))
    step=vel*io.dt
    if abs(step)>abs(delta):step=delta;vel=0.
    cmd+=step;j.q_target=cmd
    if req>seen and abs(j.q-goal)<.00035 and abs(j.dq)<.002:
        settle+=io.dt
        if settle>=.24:
            EVENTS.append({'time':round(io.time,6),'event':'index_settled','slot':req,'phase':'FEED','step':'feed_index','stroke':float(j.q),'stroke_goal':goal})
            seen=req
    else:settle=0.
    return True
