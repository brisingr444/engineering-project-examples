RECIPE='staggered'
PARTS=6
"""Measured-feedback native controller. No access to workpiece pose setters."""
import json, math
from scripts.workcell_agent.choreonoid_tasks import EVENTS as CAPTURED_EVENTS

NAMES=['X','Y','Z','JawL','JawR']
LIMITS=[(0,.20),(0,.28),(-.175,.005),(0,.021),(0,.021)]
SPEED=[.08,.08,.07,.025,.025]
ACCEL=[.35,.35,.30,.20,.20]
INPUTS=[(.10,-.125)]*6
TARGETS=[(x+(.008 if RECIPE=='staggered' and row else 0),y) for row,y in enumerate([.025,.075]) for x in [.10,.15,.20]]
HIGH=-.02; LOW=-.149

def event(io,kind,**kw):
    row=json.loads(json.dumps({'time':round(io.time,6),'event':kind,'index':index,'phase':phase,'step':f'carton{index+1}:{phase}',**kw}))
    CAPTURED_EVENTS.append(row)
    events.append(row);print('CELL '+json.dumps(row,separators=(',',':')))

def initialize(io):
    global joints,sensors,cmd,vel,index,phase,entered,stable,phase_since,occupancy,reserved,events,fault,targets,contact_lost
    joints=[io.body.link(n) for n in NAMES]
    for n in NAMES:io.enable_input(n);io.enable_output(n,'position')
    for n in ['ForceJawL','ForceJawR']:io.enable_input(n)
    sensors=[io.body.device(i) for i in range(2)]
    cmd=[float(j.q) for j in joints];vel=[0.]*5
    targets=cmd.copy();index=0;phase='START';entered=io.time;phase_since=io.time;stable=0.;contact_lost=0.
    occupancy=[False]*6;reserved=[False]*6;fault=None;events=[]
    CAPTURED_EVENTS.clear()
    event(io,'initialize',joints=cmd,devices=[s.typeName() if callable(s.typeName) else s.typeName for s in sensors])
    return True

def transition(io,next_phase):
    global phase,phase_since,stable,contact_lost
    phase=next_phase;phase_since=io.time;stable=0.;contact_lost=0.
    event(io,'transition')

def stop_fault(io,reason):
    global fault,targets,cmd,vel
    if fault is None:
        fault=reason
        targets=[float(j.q) for j in joints];cmd=targets.copy();vel=[0.]*5
        event(io,'fault',reason=reason,occupancy=occupancy.copy())

def contact():
    forces=[abs(float(s.wrench[0])) for s in sensors]
    gap=.054-float(joints[3].q)-float(joints[4].q)
    return .022<gap<.028 and min(forces)>.4,forces,gap

def control(io):
    global index,stable,targets,contact_lost,phase,cmd,vel
    dt=io.dt
    q=[float(j.q) for j in joints];dq=[float(j.dq) for j in joints]
    if not all(math.isfinite(x) for x in q+dq):stop_fault(io,'NONFINITE_FEEDBACK')
    if any(qi<lo-.0005 or qi>hi+.0005 for qi,(lo,hi) in zip(q,LIMITS)):stop_fault(io,'JOINT_LIMIT')
    if fault is None and phase not in ['DONE','START'] and io.time-phase_since>7.0:stop_fault(io,'MOTION_TIMEOUT_'+phase)
    if fault is None:
        holding,forces,gap=contact()
        if phase in ['LIFT','TRANSFER','LOWER_PLACE']:
            contact_lost=0. if holding else contact_lost+dt
            if contact_lost>.25:stop_fault(io,'GRASP_LOST')
        if phase=='START' and io.time-phase_since>.3:
            if occupancy[index] or reserved[index]:stop_fault(io,'OCCUPIED_SLOT_REUSE')
            else:
                reserved[index]=True;event(io,'reserve',slot=index)
                event(io,'index_request',slot=index);transition(io,'INDEX')
        if phase=='INDEX':
            ready_idx=any(e.get('event')=='index_settled' and e.get('slot')==index for e in CAPTURED_EVENTS[-8:])
            if ready_idx:
                targets=[INPUTS[index][0]-.06,INPUTS[index][1]+.15,HIGH,.001,.001];transition(io,'APPROACH')
            elif io.time-phase_since>4.0:stop_fault(io,'BELT_INDEX_TIMEOUT')
        motion=phase in ['APPROACH','LOWER_PICK','LIFT','TRANSFER','LOWER_PLACE','OPEN','RETRACT']
        ready=all(abs(q[i]-targets[i])<.001 and abs(dq[i])<.006 for i in range(3))
        if phase in ['APPROACH','OPEN']:ready=ready and max(q[3:])<.0015
        if motion:stable=stable+dt if ready else 0.
        if motion and stable>=.12:
            if phase=='APPROACH':targets[2]=LOW;transition(io,'LOWER_PICK')
            elif phase=='LOWER_PICK':targets[3:]=[.019,.019];transition(io,'CLOSE')
            elif phase=='LIFT':targets[:2]=[TARGETS[index][0]-.06,TARGETS[index][1]+.15];transition(io,'TRANSFER')
            elif phase=='TRANSFER':targets[2]=LOW;transition(io,'LOWER_PLACE')
            elif phase=='LOWER_PLACE':targets[3:]=[.001,.001];transition(io,'OPEN')
            elif phase=='OPEN':targets[2]=HIGH;transition(io,'RETRACT')
            elif phase=='RETRACT':transition(io,'SETTLE')
        if phase=='CLOSE':
            stable=stable+dt if holding and max(abs(v) for v in dq[3:])<.004 else 0.
            if stable>=.15:
                event(io,'grasp_confirmed',forces=forces,gap=gap)
                targets[2]=HIGH;transition(io,'LIFT')
            elif io.time-phase_since>2.0:stop_fault(io,'MISSING_PART_OR_UNCONFIRMED_GRASP')
        if phase=='SETTLE' and io.time-phase_since>=.7:
            # Reservation/commit bookkeeping is checked against independent object traces.
            if occupancy[index] or not reserved[index]:stop_fault(io,'OCCUPANCY_INVARIANT')
            else:
                occupancy[index]=True;event(io,'commit',slot=index)
                index+=1
                if index==PARTS:transition(io,'DONE');event(io,'complete',occupancy=occupancy.copy())
                else:transition(io,'START')
    for i,j in enumerate(joints):
        delta=targets[i]-cmd[i]
        desired=max(-SPEED[i],min(SPEED[i],delta/dt))
        # Braking profile avoids discontinuous acceleration at endpoints.
        brake=math.sqrt(max(0.,2*ACCEL[i]*abs(delta)))
        desired=max(-brake,min(brake,desired))
        vel[i]+=max(-ACCEL[i]*dt,min(ACCEL[i]*dt,desired-vel[i]))
        step=vel[i]*dt
        if abs(step)>abs(delta):step=delta;vel[i]=0.
        cmd[i]=max(LIMITS[i][0],min(LIMITS[i][1],cmd[i]+step))
        j.q_target=cmd[i]
    return True
