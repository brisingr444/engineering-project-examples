// Disposable synthetic machine-telemetry capture example.
module telemetry_capture (
    input  logic        PCLK,
    input  logic        PRESETn,
    input  logic        in_valid,
    output logic        in_ready,
    input  logic [31:0] in_data,
    input  logic        in_last,
    input  logic        PSEL,
    input  logic        PENABLE,
    input  logic        PWRITE,
    input  logic [7:0]  PADDR,
    input  logic [31:0] PWDATA,
    input  logic [3:0]  PSTRB,
    output logic        PREADY,
    output logic        PSLVERR,
    output logic [31:0] PRDATA
);
    localparam logic [7:0] CONTROL = 8'h00, STATUS = 8'h04,
                           LEVEL   = 8'h08, DATA   = 8'h0c;
    logic capture_enable, oversize_error, receiving, discarding;
    logic [63:0] ticks, first_tick;
    logic [31:0] sequence_next;
    logic [1:0] write_slot, read_slot;
    logic [2:0] queued;
    logic [4:0] rx_words, read_word;
    logic [31:0] payload [0:63];
    logic [31:0] seq_by_slot [0:3];
    logic [63:0] tick_by_slot [0:3];
    logic [4:0] words_by_slot [0:3];
    logic [5:0] payload_index, read_end;
    logic access_phase, apb_data_read, accept_word, packet_commit, packet_retire;
    logic storage_full;

    assign storage_full = (queued == 3'd4) || ((queued == 3'd3) && receiving);
    assign in_ready = PRESETn && (discarding || receiving ||
                                  (capture_enable && !storage_full));
    assign accept_word = in_valid && in_ready;
    assign packet_commit = accept_word && !discarding && in_last && rx_words < 5'd16;
    assign PREADY = 1'b1;
    assign access_phase = PRESETn && PSEL && PENABLE && PREADY;
    assign apb_data_read = access_phase && !PWRITE && (PADDR == DATA) && !PSLVERR;
    // Header occupies read indices 0..3, payload 4..19.
    assign read_end = 6'd3 + {1'b0, words_by_slot[read_slot]};
    assign packet_retire = apb_data_read && ({1'b0, read_word} == read_end);
    assign payload_index = {read_slot, read_word[3:0] - 4'd4};

    always_comb begin
        PRDATA  = 32'd0;
        PSLVERR = 1'b0;
        if (access_phase) begin
            case (PADDR)
                CONTROL: PRDATA = {31'd0, capture_enable};
                STATUS:  PRDATA = {28'd0, oversize_error, receiving || discarding,
                                  storage_full, queued != 0};
                LEVEL: begin
                    PSLVERR = PWRITE;
                    PRDATA = {29'd0, queued};
                end
                DATA: begin
                    if (PWRITE || queued == 0) PSLVERR = 1'b1;
                    else begin
                        case (read_word)
                            5'd0: PRDATA = seq_by_slot[read_slot];
                            5'd1: PRDATA = tick_by_slot[read_slot][31:0];
                            5'd2: PRDATA = tick_by_slot[read_slot][63:32];
                            5'd3: PRDATA = {27'd0, words_by_slot[read_slot]};
                            default: PRDATA = payload[payload_index];
                        endcase
                    end
                end
                default: PSLVERR = 1'b1;
            endcase
        end
    end

    always_ff @(posedge PCLK) begin
        if (!PRESETn) begin
            capture_enable <= 1'b0;
            oversize_error <= 1'b0;
            receiving <= 1'b0;
            discarding <= 1'b0;
            ticks <= 64'd0;
            first_tick <= 64'd0;
            sequence_next <= 32'd0;
            write_slot <= 2'd0;
            read_slot <= 2'd0;
            queued <= 3'd0;
            rx_words <= 5'd0;
            read_word <= 5'd0;
        end else begin
            ticks <= ticks + 64'd1;
            if (access_phase && PWRITE && PSTRB[0]) begin
                if (PADDR == CONTROL) capture_enable <= PWDATA[0];
                if (PADDR == STATUS && PWDATA[3]) oversize_error <= 1'b0;
            end
            if (accept_word) begin
                if (discarding) begin
                    if (in_last) discarding <= 1'b0;
                end else if (rx_words == 5'd16) begin
                    receiving <= 1'b0;
                    discarding <= !in_last;
                    rx_words <= 5'd0;
                    oversize_error <= 1'b1;
                end else begin
                    payload[{write_slot, rx_words[3:0]}] <= in_data;
                    if (!receiving) first_tick <= ticks;
                    if (packet_commit) begin
                        seq_by_slot[write_slot] <= sequence_next;
                        tick_by_slot[write_slot] <= receiving ? first_tick : ticks;
                        words_by_slot[write_slot] <= rx_words + 5'd1;
                        sequence_next <= sequence_next + 32'd1;
                        write_slot <= write_slot + 2'd1;
                        receiving <= 1'b0;
                        rx_words <= 5'd0;
                    end else begin
                        receiving <= 1'b1;
                        rx_words <= rx_words + 5'd1;
                    end
                end
            end
            if (apb_data_read) begin
                if (packet_retire) begin
                    read_slot <= read_slot + 2'd1;
                    read_word <= 5'd0;
                end else read_word <= read_word + 5'd1;
            end
            case ({packet_commit, packet_retire})
                2'b10: queued <= queued + 3'd1;
                2'b01: queued <= queued - 3'd1;
                default: ;
            endcase
        end
    end
endmodule
