# Interface and verification contract

PCLK clocks both interfaces. Active-low synchronous PRESETn resets all control state including capture enable, pointers, partial RX/read, sequence and timestamp. Memory bytes are not erased; no slot is readable until committed. This is not a secure erase primitive.

A transfer is in_valid && in_ready at a rising edge. Keep valid, data and last stable until accepted. Start is implicit on the first accepted word after reset or last. A four-slot circular store admits 1–16 words per packet. The first accepted word records the 64-bit cycle count before increment; successful last commits the descriptor and advances the modulo-32-bit sequence. A 17th word rejects that entire packet, sets the sticky status, and drains through last. Capture disable gates new admissions; in-flight receive or discard continues. Full packet occupancy can introduce a one-cycle admission bubble on retirement.

| Byte offset | APB4 register | Behavior |
|---:|---|---|
| 0x00 | CONTROL | Bit 0 capture enable, updates when PSTRB[0] is set |
| 0x04 | STATUS | Bit 0 nonempty, 1 full including reserved ingress slot, 2 receiving/discarding, 3 sticky oversize (write one to clear with PSTRB[0]) |
| 0x08 | LEVEL | Number of committed packets, 0–4; read only |
| 0x0c | DATA | Read sequence, timestamp low, timestamp high, payload count, then payload words in order; retire on final payload read |

PREADY is always high. Reads/writes are active only on selected APB access edges. Empty DATA reads, writes to LEVEL/DATA and unmapped/unaligned offsets return PSLVERR; rejected accesses do not advance data. Only one host reader; every successful DATA read advances, so reads are not idempotent. Payload lengths and timestamp units are words and PCLK cycles, not bytes or wall time.

The deterministic synthetic producer and APB sink compare actual accepted handshakes independently. Cases include four-entry full, recovery, ring wrap, maximum-length and oversized packets, masked writes, invalid accesses, and reset with unread/outbound and partial ingress state. Generic synthesis proves acceptance of this source/top by the recorded Yosys flow only.
