`timescale 1ns/1ps
module tb_telemetry_capture;
    logic PCLK=0, PRESETn=0;
    logic in_valid=0, in_last=0;
    logic [31:0] in_data=0;
    wire in_ready;
    logic PSEL=0, PENABLE=0, PWRITE=0;
    logic [7:0] PADDR=0;
    logic [31:0] PWDATA=0;
    logic [3:0] PSTRB=0;
    wire PREADY, PSLVERR;
    wire [31:0] PRDATA;
    localparam logic [7:0] CONTROL=0, STATUS=4, LEVEL=8, DATA=12;
    telemetry_capture dut(.*);
    always #5 PCLK = !PCLK;
    wire ingress_take = in_valid && in_ready;
    wire apb_readback = PRESETn && PSEL && PENABLE && PREADY && !PWRITE && PADDR==DATA && !PSLVERR;

    // Oracle only sees accepted port transfers and elapsed clocks. It does
    // not read RTL storage, pointers, occupancy, frame state, or counters.
    integer w_count=0, r_count=0, rx_length=0, offset=0;
    integer committed_total=0, read_packets=0, read_words=0, oversize_total=0;
    integer full_stall_edges=0, max_queued=0, reset_events=0, wrapped_epoch=0;
    integer discarded_on_reset=0, partial_on_reset=0, partial_read_on_reset=0;
    logic [63:0] clock_count=0, start_tick=0;
    logic [63:0] gold_tick[0:31];
    integer gold_length[0:31];
    logic [31:0] gold_payload[0:511], expected_data;
    logic was_reset=0;
    always @(posedge PCLK) begin
        if (!PRESETn) begin
            if (!was_reset) begin
                reset_events++;
                discarded_on_reset += w_count-r_count;
                if (rx_length>0) partial_on_reset++;
                if (offset>0) partial_read_on_reset++;
            end
            was_reset=1;
            w_count=0; r_count=0; rx_length=0; offset=0; clock_count=0;
        end else begin
            was_reset=0;
            if (in_valid && !in_ready && w_count-r_count==4) full_stall_edges++;
            if (apb_readback) begin
                if (r_count>=w_count) $fatal(1,"read exposed uncommitted data");
                case (offset)
                    0: expected_data=r_count;
                    1: expected_data=gold_tick[r_count][31:0];
                    2: expected_data=gold_tick[r_count][63:32];
                    3: expected_data=gold_length[r_count];
                    default: expected_data=gold_payload[16*r_count+offset-4];
                endcase
                if (PRDATA!==expected_data)
                    $fatal(1,"packet=%0d word=%0d expected=%08x actual=%08x",r_count,offset,expected_data,PRDATA);
                read_words++;
                if (offset==gold_length[r_count]+3) begin
                    $display("READ packet seq=%0d tick=%0d payload_words=%0d",r_count,gold_tick[r_count],gold_length[r_count]);
                    offset=0; r_count++; read_packets++;
                end else offset++;
            end
            if (ingress_take) begin
                if (rx_length==0) start_tick=clock_count;
                if (rx_length<16) gold_payload[16*w_count+rx_length]=in_data;
                rx_length++;
                if (in_last) begin
                    if (rx_length<=16) begin
                        gold_length[w_count]=rx_length;
                        gold_tick[w_count]=start_tick;
                        w_count++; committed_total++;
                        if (w_count>4) wrapped_epoch=1;
                        if (w_count-r_count>4) $fatal(1,"more than four committed slots");
                        if (w_count-r_count>max_queued) max_queued=w_count-r_count;
                    end else oversize_total++;
                    rx_length=0;
                end
            end
            clock_count++;
        end
    end

    task automatic apb(input bit wr, input logic [7:0] addr, input logic [31:0] value,
                       input logic [3:0] strobes, input bit expected_error, output logic [31:0] result);
        @(negedge PCLK);
        PSEL=1; PENABLE=0; PWRITE=wr; PADDR=addr; PWDATA=value; PSTRB=strobes;
        @(negedge PCLK); PENABLE=1;
        @(posedge PCLK);
        if (PREADY!==1'b1 || PSLVERR!==expected_error)
            $fatal(1,"APB response address=%02x write=%d ready=%b error=%b expected_error=%b",
                   addr,wr,PREADY,PSLVERR,expected_error);
        result=PRDATA;
        @(negedge PCLK); PSEL=0; PENABLE=0;
    endtask

    task automatic write_reg(input logic [7:0] addr,input logic [31:0] value,
                             input logic [3:0] strobes,input bit expected_error=0);
        logic [31:0] ignored;
        apb(1,addr,value,strobes,expected_error,ignored);
    endtask
    task automatic expect_reg(input logic [7:0] addr,input logic [31:0] expected,
                              input bit expected_error=0);
        logic [31:0] actual;
        apb(0,addr,0,0,expected_error,actual);
        if (actual!==expected) $fatal(1,"register %02x expected=%08x actual=%08x",addr,expected,actual);
    endtask

    task automatic send_word(input logic [31:0] word_value,input bit last);
        @(negedge PCLK); in_valid=1; in_data=word_value; in_last=last;
        do @(posedge PCLK); while (in_ready!==1'b1);
        @(negedge PCLK); in_valid=0; in_last=0;
    endtask
    task automatic produce(input logic [31:0] base,input int len);
        for (int i=0;i<len;i++) send_word(base+i,i==len-1);
    endtask
    task automatic receive(input int len);
        logic [31:0] value;
        for (int i=0;i<len+4;i++) apb(0,DATA,0,0,0,value);
    endtask

    logic [31:0] ignored;
    initial begin
        $dumpfile("waveform.vcd");
        $dumpvars(0,PCLK,PRESETn,in_valid,in_ready,ingress_take,in_last,in_data,
            PSEL,PENABLE,PWRITE,PADDR,PREADY,PSLVERR,PRDATA,apb_readback,
            dut.packet_commit,dut.packet_retire,dut.queued,dut.storage_full,dut.oversize_error);
        repeat (3) @(negedge PCLK); PRESETn=1;
        expect_reg(CONTROL,0);
        write_reg(CONTROL,1,4'b1000);
        expect_reg(CONTROL,0);
        expect_reg(DATA,0,1);
        expect_reg(8'h0d,0,1);
        write_reg(LEVEL,123,4'hf,1);
        write_reg(CONTROL,1,4'h1);

        produce(32'hA0,2); produce(32'hB0,1); produce(32'hC0,3); produce(32'hD0,16);
        expect_reg(LEVEL,4); expect_reg(STATUS,3);
        fork
            produce(32'hE0,2);
            begin
                repeat (6) @(negedge PCLK);
                if (!in_valid || in_ready || in_data!==32'hE0 || in_last)
                    $fatal(1,"producer was not held at full boundary");
                receive(2);
            end
        join
        expect_reg(LEVEL,4);
        receive(1); receive(3); receive(16); receive(2);
        expect_reg(LEVEL,0); expect_reg(DATA,0,1);

        // Beyond the 16th word: drain oversize tail, never expose it or consume a sequence.
        produce(32'hF0,18);
        expect_reg(STATUS,8); expect_reg(LEVEL,0); expect_reg(DATA,0,1);
        write_reg(STATUS,8,4'b0010); expect_reg(STATUS,8);
        write_reg(STATUS,8,4'b0001); expect_reg(STATUS,0);
        produce(32'h120,1); receive(1);
        produce(32'h130,1); produce(32'h140,1);
        apb(0,DATA,0,0,0,ignored);
        send_word(32'h150,0); expect_reg(STATUS,5);

        @(negedge PCLK); PRESETn=0;
        repeat (2) @(negedge PCLK); PRESETn=1;
        expect_reg(CONTROL,0); expect_reg(STATUS,0); expect_reg(LEVEL,0); expect_reg(DATA,0,1);
        if (in_ready) $fatal(1,"reset should disable new captures");
        write_reg(CONTROL,1,4'h1);
        produce(32'h200,2); receive(2); expect_reg(DATA,0,1); expect_reg(LEVEL,0);
        if (committed_total!=9 || read_packets!=7 || read_words!=56 ||
            max_queued!=4 || full_stall_edges<6 || !wrapped_epoch || oversize_total!=1 ||
            reset_events!=2 || discarded_on_reset!=2 || partial_on_reset!=1 || partial_read_on_reset!=1)
            $fatal(1,"unexpected coverage: commits=%0d drained=%0d words=%0d",committed_total,read_packets,read_words);
        $display("PASS telemetry: committed=%0d fully_read=%0d data_window_words=%0d full_stall_edges=%0d max_queued=%0d wrap=%0d oversize=%0d reset_flushed=%0d reset_partial_ingress=%0d reset_partial_read=%0d",
                 committed_total,read_packets,read_words,full_stall_edges,max_queued,wrapped_epoch,
                 oversize_total,discarded_on_reset,partial_on_reset,partial_read_on_reset);
        $finish;
    end
    initial begin
        #30000;
        $fatal(1,"bounded watchdog expired");
    end
endmodule
